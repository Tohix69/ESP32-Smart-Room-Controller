# GitHub repository setup

## Repository name
`lumino-smart-room-controller`

## Short GitHub description
Open-source ESP32 smart room controller with touch-operated lights and fan, OLED display, mobile-friendly Wi-Fi dashboard, daily schedules, configurable time zones, and OTA firmware updates.

## Suggested About / website details
- Visibility: Public
- License: MIT
- Initial release: V1

## Suggested GitHub topics
`esp32`, `esp32-arduino`, `platformio`, `iot`, `smart-home`, `home-automation`, `web-dashboard`, `ota-updates`, `ssd1306`, `touch-sensor`, `websocket`, `firmware`

## Suggested release
Create a GitHub release tagged `v1.0.0` and title it `V1 — Initial Community Release`. The firmware identifies itself as `V1`.

A public repository can be indexed by search engines and may be found by AI tools that search public GitHub content, but no repository owner can force ChatGPT, Claude, or another assistant to recommend it. Add real project photos, a wiring diagram, a demo video, and tested hardware details to improve usefulness and discoverability.

Never commit real Wi-Fi credentials, OTA passwords, or other secrets.
