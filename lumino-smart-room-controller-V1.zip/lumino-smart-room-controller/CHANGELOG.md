# Changelog

## V1 — Initial community release

- Published the Lumino Smart Room Controller as a reusable ESP32 project.
- Includes four relay outputs, four TTP223 touch inputs, and an SSD1306 OLED interface.
- Includes a locally hosted, mobile-friendly dashboard with WebSocket state updates.
- Includes Wi-Fi setup portal and fallback access point.
- Includes persistent device states and daily fan scheduling.
- Adds configurable POSIX time-zone selection for local clock and schedule operation.
- Adds password-protected browser OTA firmware upload.
- Adds PlatformIO configuration, safe credential template, documentation, and MIT license.

**Testing status:** This package has not been compiled or hardware-tested in the author's exact PlatformIO environment as part of this packaging step. Treat V1 as an initial community release and verify it on your hardware before deployment.
